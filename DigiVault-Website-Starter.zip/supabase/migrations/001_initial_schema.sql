-- DigiVault initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  description text not null default '',
  price numeric(10,2) not null check (price >= 0),
  icon text not null default '✦',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  customer_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  email text not null,
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'pending_payment'
    check (status in ('pending_payment','paid','cancelled','refunded')),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  unit_price numeric(10,2) not null check (unit_price >= 0),
  quantity integer not null default 1 check (quantity > 0)
);

create table if not exists public.payment_settings (
  id uuid primary key default gen_random_uuid(),
  provider text unique not null,
  enabled boolean not null default false,
  configured boolean not null default false,
  created_at timestamptz not null default now()
);

insert into public.payment_settings(provider,enabled,configured)
values ('stripe',false,false),('paypal',false,false),('crypto_provider',false,false)
on conflict(provider) do nothing;

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payment_settings enable row level security;

-- Public can only view active products. Admin can manage products.
create policy "Public reads active products" on public.products
for select using (active = true or exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));
create policy "Admins manage products" on public.products
for all using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'))
with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));

-- Customers may create pending orders only. They can read their own orders.
create policy "Customers create pending orders" on public.orders
for insert with check (
  status='pending_payment' and customer_id=auth.uid()
);
create policy "Customers read own orders" on public.orders
for select using (
  customer_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);
create policy "Admins update orders" on public.orders
for update using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'))
with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));

create policy "Users read own order items" on public.order_items
for select using (exists(select 1 from public.orders o where o.id=order_id and (o.customer_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'))));
create policy "Customers add items to own pending orders" on public.order_items
for insert with check (exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid() and o.status='pending_payment'));

create policy "Only admins read payment settings" on public.payment_settings
for select using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));
create policy "Only admins manage payment settings" on public.payment_settings
for all using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'))
with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));

-- Profile row is created automatically; users cannot self-assign admin role.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name,role)
  values(new.id, coalesce(new.raw_user_meta_data->>'display_name',''), 'customer');
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT: promote the intended administrator manually from the SQL Editor
-- only after creating their account:
-- update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';
